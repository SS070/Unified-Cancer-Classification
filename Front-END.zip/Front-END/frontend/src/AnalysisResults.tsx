import { useState, useCallback, useMemo, memo, useRef, useEffect } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle,
  PieChart,
  BarChart,
  Activity,
  Info,
  List,
  FileWarning,
  Stethoscope,
  Clock,
  Heart,
  MapPin,
  Gauge,
  Layers3,
  Loader2,
  FileText,
  DownloadCloud,
  Globe2,
  Landmark,
  Eye,
  Layout
} from 'lucide-react';
import Plot from 'react-plotly.js';
import './AnalysisResults.css';

// --- Interfaces ---
interface AlternativePrediction {
  readable_name: string;
  organ: string;
  confidence: number;
  brief_info: string;
}

interface CancerInfo {
  description: string;
  details: string;
  patient_implications: string;
  common_treatments: string;
}

interface GradCamFile {
  layer: string;
  file: string | null;
}
interface GradCamResult {
  status: string;
  gradcam_files: GradCamFile[];
}

interface RecommendationEntry {
  label: string;
  recs: string[];
  priority: 'high' | 'standard';
}

interface PredictionResult {
  prediction: {
    class: string;
    confidence: number;
    readable_name: string;
    organ: string;
  };
  all_confidences: Record<string, number>;
  filename: string;
  meta: {
    organ: string;
    is_malignant: boolean;
  };
  visualizations: {
    bar_chart: string;
    organ_chart: string;
    pie_chart: string;
    umap3d_data?: any;
    manhattan3d_data?: any;
    // legacy keys for backward compatibility:
    plot3d?: string;
    plot3d_interactive?: string;
    plot3d_data?: any;
    plot3d_interactive_data?: any;
  };
  cancer_info?: CancerInfo;
  alternatives_info?: AlternativePrediction[];
  plot3d_data?: any;
  plot3d_interactive_data?: any;
  umap3d_data?: any;
  manhattan3d_data?: any;
}

// -- recommendationsMap (Insert your full map here, for brevity only a stub) --
const recommendationsMap: Record<string, RecommendationEntry> = {
  // ... (unchanged, see previous code for full map)
  all_benign: {
    label: "Benign Leukemia-related Findings",
    priority: "standard",
    recs: [
      "No evidence of malignant leukemia detected in the specimen.",
      "Recommend routine hematological monitoring as per standard guidelines.",
      "Patient education on symptoms of blood disorders and when to seek medical attention.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  all_early: {
    label: "Early Leukemia Recommendations",
    priority: "high",
    recs: [
      "Prompt referral to hematology for further diagnostic confirmation and risk stratification.",
      "Initiate baseline laboratory workup (CBC, peripheral smear, bone marrow biopsy as indicated).",
      "Discuss early treatment options and clinical trial eligibility with the patient.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  all_pre: {
    label: "Pre-leukemic Condition Recommendations",
    priority: "standard",
    recs: [
      "Close hematological surveillance for progression to overt leukemia.",
      "Genetic and molecular testing to assess risk of transformation.",
      "Counsel patient on symptoms of acute leukemia and the importance of regular follow-up.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  all_pro: {
    label: "Progressed/Advanced Leukemia Recommendations",
    priority: "high",
    recs: [
      "Initiate staging workup, including bone marrow biopsy and cytogenetic analysis.",
      "Multidisciplinary team evaluation for chemotherapy, targeted therapy, or stem cell transplantation.",
      "Provide psychosocial support, patient counseling, and discuss palliative care options if appropriate.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  // Brain
  brain_glioma: {
    label: "Brain Glioma Recommendations",
    priority: "high",
    recs: [
      "Neurosurgery consult for resection evaluation.",
      "Brain MRI for further characterization and staging.",
      "Discuss adjuvant therapy options with neuro-oncology.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  brain_menin: {
    label: "Brain Meningioma Recommendations",
    priority: "high",
    recs: [
      "Monitor with periodic MRI if asymptomatic.",
      "Neurosurgical evaluation if symptomatic or growing.",
      "Discuss potential for radiotherapy if not surgical candidate.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  brain_notumor: {
    label: "Normal Brain Tissue",
    priority: "standard",
    recs: [
      "No tumor detected.",
      "Routine neurological care as indicated.",
      "No specific oncologic intervention required.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  brain_tumor: {
    label: "Brain Tumor (Other) Recommendations",
    priority: "high",
    recs: [
      "Further neuropathological workup for tumor typing.",
      "Neurosurgical and oncology consult.",
      "Initiate multidisciplinary tumor board review.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  // Breast
  breast_benign: {
    label: "Benign Breast Lesion Recommendations",
    priority: "standard",
    recs: [
      "Routine clinical follow-up; consider imaging surveillance.",
      "No immediate intervention unless symptomatic.",
      "Patient education on breast self-exam.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  breast_malignant: {
    label: "Malignant Breast Lesion Recommendations",
    priority: "high",
    recs: [
      "Referral to breast oncology specialist.",
      "Imaging for staging (mammography, MRI, ultrasound).",
      "Discuss surgical and systemic therapy options.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  // Cervix
  cervix_dyk: {
    label: "Cervical Dyskaryosis Recommendations",
    priority: "high",
    recs: [
      "Colposcopy-guided biopsy for confirmation.",
      "Repeat cytology or HPV testing as per guidelines.",
      "Patient counseling on HPV vaccination.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  cervix_koc: {
    label: "Cervical Koilocytosis Recommendations",
    priority: "standard",
    recs: [
      "Monitor with regular Pap smears.",
      "HPV DNA testing if indicated.",
      "Patient education on safe practices.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  cervix_mep: {
    label: "Cervical Metaplasia Recommendations",
    priority: "standard",
    recs: [
      "Routine follow-up with cytology.",
      "No immediate intervention unless progression occurs.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  cervix_pab: {
    label: "Cervical Parabasalia Recommendations",
    priority: "standard",
    recs: [
      "Follow up with cytology as indicated.",
      "Consider further evaluation if atypical features found.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  cervix_sfi: {
    label: "Cervical Superficial Cell Recommendations",
    priority: "standard",
    recs: [
      "Routine gynecological care.",
      "No intervention needed unless abnormal symptoms.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  // Colon
  colon_aca: {
    label: "Colonic Adenocarcinoma Recommendations",
    priority: "high",
    recs: [
      "Refer to colorectal oncology for staging and management.",
      "CT scan for metastasis evaluation.",
      "Discuss surgical and adjuvant therapy options.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  colon_bnt: {
    label: "Benign Colonic Tissue Recommendations",
    priority: "standard",
    recs: [
      "Routine follow-up unless symptoms develop.",
      "Colonoscopy surveillance as per guidelines.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  // Kidney
  kidney_normal: {
    label: "Normal Kidney Tissue",
    priority: "standard",
    recs: [
      "No abnormality detected.",
      "Routine nephrological care as indicated.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  kidney_tumor: {
    label: "Kidney Tumor Recommendations",
    priority: "high",
    recs: [
      "Urology consult for further workup.",
      "Abdominal imaging for staging.",
      "Discuss nephrectomy and adjuvant therapy.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  // Lung
  lung_aca: {
    label: "Lung Adenocarcinoma Recommendations",
    priority: "high",
    recs: [
      "Refer to thoracic oncology for evaluation.",
      "PET/CT for staging.",
      "Discuss surgical and systemic therapy.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  lung_bnt: {
    label: "Benign Lung Tissue Recommendations",
    priority: "standard",
    recs: [
      "Routine follow-up.",
      "No oncologic intervention required.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  lung_scc: {
    label: "Lung Squamous Cell Carcinoma Recommendations",
    priority: "high",
    recs: [
      "Oncology referral for treatment planning.",
      "Staging with imaging.",
      "Consider chemoradiation and/or surgery.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  // Lymph
  lymph_cll: {
    label: "Chronic Lymphocytic Leukemia Recommendations",
    priority: "high",
    recs: [
      "Hematology consult for further management.",
      "Flow cytometry or molecular testing.",
      "Patient education on infection risk.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  lymph_fl: {
    label: "Follicular Lymphoma Recommendations",
    priority: "high",
    recs: [
      "Staging with PET/CT.",
      "Evaluate for chemotherapy or immunotherapy.",
      "Consider watchful waiting if asymptomatic.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  lymph_mcl: {
    label: "Mantle Cell Lymphoma Recommendations",
    priority: "high",
    recs: [
      "Hematology/oncology referral.",
      "Staging and risk stratification.",
      "Discuss stem cell transplant if eligible.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  },
  // Oral
  oral_normal: {
    label: "Normal Oral Mucosa",
    priority: "standard",
    recs: [
      "No abnormality detected.",
      "Routine dental and medical care.",
      "Routine follow-up as per clinical guidelines",
      "Surveillance if clinically indicated",
      "Correlate with clinical and imaging findings"
    ]
  },
  oral_scc: {
    label: "Oral Squamous Cell Carcinoma Recommendations",
    priority: "high",
    recs: [
      "Head and neck oncology referral.",
      "Imaging for local and regional staging.",
      "Assess for surgical and adjuvant therapy.",
      "Immediate specialist review strongly recommended",
      "Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted",
      "Multidisciplinary team meeting for further management planning",
      "Ensure comprehensive documentation and patient counseling"
    ]
  }
};


function getClinicalRecommendations(className: string, isMalignant: boolean): RecommendationEntry {
  if (recommendationsMap[className]) {
    return recommendationsMap[className];
  }
  if (isMalignant) {
    return {
      label: 'General High Priority Recommendations',
      priority: 'high',
      recs: [
        'Immediate specialist review strongly recommended',
        'Additional diagnostic workup (immunohistochemistry, molecular testing) may be warranted',
        'Multidisciplinary team meeting for further management planning',
        'Ensure comprehensive documentation and patient counseling',
      ],
    };
  }
  return {
    label: 'General Standard Follow-up Recommendations',
    priority: 'standard',
    recs: [
      'Routine follow-up as per clinical guidelines',
      'Surveillance if clinically indicated',
      'Correlate with clinical and imaging findings',
    ],
  };
}


const VisualizationTabs = memo(
  ({
    prediction,
    activeTab,
    setActiveTab,
  }: {
    prediction: PredictionResult;
    activeTab: string;
    setActiveTab: (tab: string) => void;
  }) => {
    const barChartUrl = useMemo(
      () => `http://localhost:5000/visualizations/${prediction.visualizations.bar_chart}`,
      [prediction.visualizations.bar_chart]
    );
    const organChartUrl = useMemo(
      () => `http://localhost:5000/visualizations/${prediction.visualizations.organ_chart}`,
      [prediction.visualizations.organ_chart]
    );
    const pieChartUrl = useMemo(
      () => `http://localhost:5000/visualizations/${prediction.visualizations.pie_chart}`,
      [prediction.visualizations.pie_chart]
    );


    const umap3dData =
      prediction.visualizations.umap3d_data || prediction.umap3d_data || null;
    const manhattan3dData =
      prediction.visualizations.manhattan3d_data || prediction.manhattan3d_data || null;

    return (
      <div className="viz-tabs-container">
        <div className="viz-tabs-header">
          <button
            className={`viz-tab-button ${activeTab === 'bar' ? 'viz-tab-active' : 'viz-tab-inactive'}`}
            onClick={() => setActiveTab('bar')}
          >
            <BarChart size={16} className="viz-tab-icon" /> Top Classes
          </button>
          <button
            className={`viz-tab-button ${activeTab === 'organ' ? 'viz-tab-active' : 'viz-tab-inactive'}`}
            onClick={() => setActiveTab('organ')}
          >
            <Activity size={16} className="viz-tab-icon" /> Organ Analysis
          </button>
          <button
            className={`viz-tab-button ${activeTab === 'pie' ? 'viz-tab-active' : 'viz-tab-inactive'}`}
            onClick={() => setActiveTab('pie')}
          >
            <PieChart size={16} className="viz-tab-icon" /> Benign vs Malignant
          </button>
          {}
          <button
            className={`viz-tab-button ${activeTab === 'umap3d' ? 'viz-tab-active' : 'viz-tab-inactive'}`}
            onClick={() => setActiveTab('umap3d')}
            disabled={!umap3dData}
            title={!umap3dData ? '3D UMAP unavailable for this prediction' : undefined}
          >
            <Globe2 size={16} className="viz-tab-icon" /> Patient Embedding Highlight (3D UMAP)
          </button>
          <button
            className={`viz-tab-button ${activeTab === 'manhattan3d' ? 'viz-tab-active' : 'viz-tab-inactive'}`}
            onClick={() => setActiveTab('manhattan3d')}
            disabled={!manhattan3dData}
            title={!manhattan3dData ? '3D Manhattan unavailable for this prediction' : undefined}
          >
            <Landmark size={16} className="viz-tab-icon" /> Manhattan 3D
          </button>
        </div>
        <div className="viz-tab-content">
          {activeTab === 'bar' && (
            <div className="viz-image-container">
              <img
                src={barChartUrl}
                alt="Top 5 Predictions Chart"
                className="viz-chart-image"
                loading="lazy"
              />
              <p className="viz-chart-caption">Top 5 classification results by confidence</p>
            </div>
          )}
          {activeTab === 'organ' && (
            <div className="viz-image-container">
              <img
                src={organChartUrl}
                alt="Organ Analysis Chart"
                className="viz-chart-image"
                loading="lazy"
              />
              <p className="viz-chart-caption">Highest confidence prediction by organ/region</p>
            </div>
          )}
          {activeTab === 'pie' && (
            <div className="viz-image-container">
              <img
                src={pieChartUrl}
                alt="Benign vs Malignant Chart"
                className="viz-chart-image"
                loading="lazy"
              />
              <p className="viz-chart-caption">Aggregate benign vs malignant probability assessment</p>
            </div>
          )}
          {}
          {activeTab === 'umap3d' && (
            <div className="viz-3d-plot-container">
              {umap3dData ? (
                <>
                  <Plot
                    data={umap3dData.data}
                    layout={umap3dData.layout}
                    config={umap3dData.config || { responsive: true, displayModeBar: false }}
                    style={{ width: '100%', height: '430px' }}
                  />
                  <p className="viz-chart-caption">
                    Patient Embedding Highlight in 3D UMAP: Your sample's position in the learned feature space is shown by a highlighted marker.
                  </p>
                </>
              ) : (
                <div className="viz-3d-plot-placeholder">No Patient Embedding UMAP 3D plot available.</div>
              )}
            </div>
          )}
          {activeTab === 'manhattan3d' && (
            <div className="viz-3d-plot-container">
              {manhattan3dData ? (
                <>
                  <Plot
                    data={manhattan3dData.data}
                    layout={manhattan3dData.layout}
                    config={manhattan3dData.config || { responsive: true, displayModeBar: false }}
                    style={{ width: '100%', height: '430px' }}
                  />
                  <p className="viz-chart-caption">3D Manhattan: Organ-category confidence landscape</p>
                </>
              ) : (
                <div className="viz-3d-plot-placeholder">No Manhattan 3D plot available.</div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }
);
VisualizationTabs.displayName = 'VisualizationTabs';

// --- Grad-CAM Section (2D overlays only, NOT 3D) ---
const GradCamSection = memo(
  ({
    prediction,
    gradCamLoading,
    gradCamResult,
    gradCamError,
    onGradCamFetch,
  }: {
    prediction: PredictionResult;
    gradCamLoading?: boolean;
    gradCamResult?: GradCamResult | null;
    gradCamError?: string | null;
    onGradCamFetch?: () => void;
  }) => {
    const [activeGradLayer, setActiveGradLayer] = useState<number>(0);

    const gradcamImages = useMemo(() => {
      if (!gradCamResult?.gradcam_files) return [];
      return gradCamResult.gradcam_files.filter((g) => g.file !== null);
    }, [gradCamResult]);

    return (
      <div className="gradcam-section">
        <h3 className="gradcam-title">
          <Layers3 size={20} style={{ marginRight: 6 }} />
          Advanced Medical Visualizations
        </h3>
        <h3 className="gradcam-title">
          <span style={{ fontWeight: 400, fontSize: '0.9em' }}>(Multi-Layer Grad-CAM)</span>
        </h3>
        <p className="gradcam-description">
          Note: The visualizations below highlight regions of the uploaded image that most influenced the AI's prediction, across multiple layers of the Xception model.
        </p>
        {!gradCamResult && (
          <button
            className="gradcam-fetch-btn"
            onClick={onGradCamFetch}
            disabled={gradCamLoading}
          >
            {gradCamLoading ? <><Loader2 className="spin" size={18} /> Generating...</> : <>Generate Grad-CAM Visualizations</>}
          </button>
        )}
        {gradCamError && (
          <div className="gradcam-error">
            <AlertCircle size={16} /> {gradCamError}
          </div>
        )}
        {gradCamLoading && (
          <div className="gradcam-loading">
            <Loader2 className="spin" size={18} /> Generating Grad-CAM overlays...
          </div>
        )}
        {gradcamImages.length > 0 && (
          <div className="gradcam-images-wrapper">
            <div className="gradcam-image-controls">
              <span>Layer:</span>
              <select
                value={activeGradLayer}
                onChange={(e) => setActiveGradLayer(Number(e.target.value))}
              >
                {gradcamImages.map((img, idx) => (
                  <option key={idx} value={idx}>
                    {img.layer}
                  </option>
                ))}
              </select>
              <span className="gradcam-layer-label">{gradcamImages[activeGradLayer]?.layer}</span>
            </div>
            <div className="gradcam-image-container">
              <img
                src={`http://localhost:5000/visualizations/${gradcamImages[activeGradLayer]?.file}`}
                alt={`Grad-CAM visualization for ${gradcamImages[activeGradLayer]?.layer}`}
                className="gradcam-image"
                loading="lazy"
              />
            </div>
            <div className="gradcam-image-caption">
              <strong>Layer:</strong> {gradcamImages[activeGradLayer]?.layer}
            </div>
          </div>
        )}
      </div>
    );
  }
);
GradCamSection.displayName = 'GradCamSection';

// --- Cancer Information Section ---
const CancerInformationSection = memo(
  ({
    cancerInfo,
    isMalignant,
  }: {
    cancerInfo: CancerInfo;
    isMalignant: boolean;
  }) => (
    <div className="cancer-info-section">
      <h3 className="cancer-info-title">
        <Info size={20} className="cancer-info-icon" /> Medical Information
      </h3>
      <div className="cancer-info-grid">
        <div className="cancer-info-card">
          <h4 className="cancer-info-card-title">
            <FileWarning size={18} className="cancer-info-card-icon" />
            Description
          </h4>
          <p className="cancer-info-card-content">{cancerInfo.description}</p>
        </div>
        <div className="cancer-info-card">
          <h4 className="cancer-info-card-title">
            <Stethoscope size={18} className="cancer-info-card-icon" />
            Medical Details
          </h4>
          <p className="cancer-info-card-content">{cancerInfo.details}</p>
        </div>
        <div className="cancer-info-card">
          <h4 className="cancer-info-card-title">
            <Clock size={18} className="cancer-info-card-icon" />
            Patient Implications
          </h4>
          <p className="cancer-info-card-content">{cancerInfo.patient_implications}</p>
        </div>
        <div className="cancer-info-card">
          <h4 className="cancer-info-card-title">
            <Heart size={18} className="cancer-info-card-icon" />
            Common Treatment Options
          </h4>
          <p className="cancer-info-card-content">{cancerInfo.common_treatments}</p>
        </div>
      </div>
    </div>
  )
);
CancerInformationSection.displayName = 'CancerInformationSection';

// --- Enhanced Analysis Report Section ---
const EnhancedAnalysisReport = memo(
  ({
    prediction,
    downloadableContentRef,
    uploadedImageUrl,
    reportId,
  }: {
    prediction: PredictionResult;
    downloadableContentRef?: React.RefObject<HTMLDivElement>;
    uploadedImageUrl: string;
    reportId: string;
  }) => {
    const isMalignant = prediction.meta.is_malignant;
    const confidence = prediction.prediction.confidence;
    const confidenceLevel =
      confidence >= 0.9
        ? 'Very High'
        : confidence >= 0.7
        ? 'High'
        : confidence >= 0.5
        ? 'Moderate'
        : 'Low';

    // Date formatting
    const currentDate = new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    const allConfidences = Object.entries(prediction.all_confidences);
    const sortedConfidences = allConfidences
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5);

    const topAlternatives = prediction.alternatives_info?.slice(0, 3) || [];

    // NEW: Get tailored recommendations (with priority)
    const { label: recLabel, recs: recList, priority } = getClinicalRecommendations(prediction.prediction.class, isMalignant);
    const priorityText = priority === "high" ? "HIGH PRIORITY:" : "STANDARD FOLLOW-UP:";

    return (
      <div className="enhanced-analysis-report" ref={downloadableContentRef}>
        <div className="enhanced-report-header-flex">
          <div className="enhanced-report-header">
            <FileText size={22} style={{ marginRight: '10px', color: '#0369a1' }} />
            <span className="enhanced-report-title">
              ARTIFICIAL INTELLIGENCE PATHOLOGY ANALYSIS REPORT
            </span>
          </div>
          <div className="report-uploaded-image-wrapper">
            <img
              src={uploadedImageUrl}
              alt="Uploaded for analysis"
              className="report-uploaded-image"
              loading="lazy"
            />
          </div>
        </div>
        <div className="enhanced-metadata-row">
          <span className="enhanced-metadata">
            <strong>Generated:</strong> {currentDate}
          </span>
          <span className="enhanced-metadata">
            <strong>Report ID:</strong> {reportId}
          </span>
          <span className="enhanced-metadata">
            <strong>AI Model:</strong> Xception v2.1 Deep Neural Network
          </span>
        </div>
        {/* Clinical Summary */}
        <section className="enhanced-section">
          <h4 className="enhanced-section-title">I) CLINICAL SUMMARY</h4>
          <div className="enhanced-section-content">
            <div className="enhanced-summary-grid">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div>
                  <span className="enhanced-summary-label">Primary Diagnosis:</span>
                  <span className="enhanced-summary-value">{prediction.prediction.readable_name}</span>
                </div>
                <div>
                  <span className="enhanced-summary-label">Anatomical Site:</span>
                  <span className="enhanced-summary-value">{prediction.prediction.organ}</span>
                </div>
                <div>
                  <span className="enhanced-summary-label">Reference Image:</span>
                  <span className="enhanced-summary-value">{prediction.filename}</span>
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div>
                  <span className="enhanced-summary-label">Malignancy Status:</span>
                  <span className={`enhanced-summary-value ${isMalignant ? 'malignant' : 'benign'}`}>
                    {isMalignant ? 'POTENTIALLY MALIGNANT' : 'LIKELY BENIGN'}
                  </span>
                </div>
                <div>
                  <span className="enhanced-summary-label">Diagnostic Confidence:</span>
                  <span className="enhanced-summary-value">
                    {confidenceLevel} ({Math.round(confidence * 100)}%)
                  </span>
                </div>
                <div>
                  <span className="enhanced-summary-label">Top Alternative:</span>
                  <span className="enhanced-summary-value">
                    {topAlternatives.length > 0
                      ? `${topAlternatives[0].readable_name} (${Math.round(
                          topAlternatives[0].confidence * 100
                        )}%)`
                      : 'N/A'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Technical Analysis */}
        <section className="enhanced-section">
          <h4 className="enhanced-section-title">II) TECHNICAL ANALYSIS</h4>
          <div className="enhanced-section-content">
            <div className="enhanced-tech-methodology">
              <h5>Methodology</h5>
              <ul>
                <li>
                  <strong>Deep Learning Architecture:</strong> Xception Convolutional Neural Network
                </li>
                <li>
                  <strong>Analysis Type:</strong> Multi-class histopathological tissue classification
                </li>
                <li>
                  <strong>Feature Extraction:</strong> Automated pattern recognition, multi-layer feature abstraction
                </li>
                <li>
                  <strong>Processing Pipeline:</strong> Automated preprocessing, normalization, augmentation, robust classification
                </li>
                <li>
                  <strong>Quality Control:</strong> Model validated with cross-sectional, multi-institutional datasets
                </li>
              </ul>
            </div>
            <div className="enhanced-tech-results">
              <h5>Classification Results (Top 5)</h5>
              <table className="enhanced-results-table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Classification</th>
                    <th>Confidence</th>
                    <th>Probability</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedConfidences.map(([className, conf], idx) => (
                    <tr key={idx} className={idx === 0 ? 'primary-result' : ''}>
                      <td>{idx + 1}:</td>
                      <td className="classification-cell">
                        {className.replace(/_/g, ' ').toUpperCase()}
                      </td>
                      <td style={{ paddingLeft: '3%' }}>{Math.round(conf * 100)}%</td>
                      <td style={{ paddingLeft: '3%' }}>{conf.toFixed(5)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="enhanced-tech-precision">
                <p>
                  <strong>Model precision:</strong> The AI model delivers high sensitivity and specificity for most tissue types, but rare class variants may require additional review.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Clinical Interpretation */}
        <section className="enhanced-section">
          <h4 className="enhanced-section-title">III) CLINICAL INTERPRETATION</h4>
          <div className="enhanced-section-content">
            <div className="enhanced-interpretation-block">
              <h5 className="enhanced-interpretation-heading">Risk Stratification</h5>
              <p>
                <span className="bold">
                  {isMalignant
                    ? 'This specimen demonstrates histopathological features highly suggestive of malignant transformation.'
                    : 'This specimen exhibits features consistent with benign tissue.'}
                </span>
                <br />
                The AI system's diagnostic confidence is{' '}
                <span className="bold">{confidenceLevel.toLowerCase()}</span> (
                {Math.round(confidence * 100)}%).
                {confidence >= 0.8
                  ? ' This is considered a high-reliability result, but clinical correlation is always recommended.'
                  : ' Due to moderate confidence, further pathological review and correlation with clinical findings are advised.'}
              </p>
            </div>

            <div className="enhanced-interpretation-block">
              <h5 className="enhanced-interpretation-heading">Differential Diagnosis</h5>
              {topAlternatives.length > 0 ? (
                <>
                  <p><strong>Other possibilities based on pattern recognition and model output:</strong></p>
                  <ul className="enhanced-differential-list">
                    {topAlternatives.map((alt, idx) => (
                      <li key={idx}>
                        <span className="alt-name">{alt.readable_name}</span>
                        <span className="alt-organ">({alt.organ})</span>
                        <span className="alt-conf">- {Math.round(alt.confidence * 100)}% confidence</span>
                        <span className="alt-info">{alt.brief_info ? ` — ${alt.brief_info}` : ''}</span>
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <p>No significant alternative diagnoses identified with notable confidence levels.</p>
              )}
            </div>

            <div className="enhanced-interpretation-block">
              <h5 className="enhanced-interpretation-heading">Clinical Recommendations</h5>
              <div className={`enhanced-recommendations ${priority === "high" ? "high-priority" : "standard-priority"}`}>
                <p className="recommendation-priority">{priorityText}</p>
                <p style={{ fontWeight: 600, marginBottom: 3 }}>{recLabel}</p>
                <ol>
                  {recList.map((rec, idx) => (
                    <li key={idx}>{rec}</li>
                  ))}
                </ol>
              </div>
            </div>
          </div>
        </section>

        {/* Final Assessment */}
        <section className="enhanced-section">
          <h4 className="enhanced-section-title">IV) FINAL ASSESSMENT</h4>
          <div className="enhanced-section-content">
            <div className="enhanced-final-assessment">
              <p>
                <strong>CONCLUSION:</strong> AI-assisted analysis identifies{' '}
                <strong>{prediction.prediction.readable_name.toUpperCase()}</strong> in the{' '}
                <strong>{prediction.prediction.organ.toLowerCase()}</strong> region with{' '}
                <span className="bold">{confidenceLevel.toLowerCase()}</span> diagnostic confidence (
                {Math.round(confidence * 100)}%). The sample demonstrates features
                {isMalignant ? ' raising concern for malignant disease.' : ' consistent with benign tissue.'}
              </p>
              {confidence < 0.7 && (
                <div className="enhanced-quality-note">
                  <p>
                    <strong>QUALITY NOTE:</strong> Results below high-confidence thresholds require specialist review. AI analysis should supplement, not replace, expert pathology.
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Report Footer */}
        <div className="enhanced-report-footer">
          <div className="enhanced-footer-note">
            <p>
              <strong>Limitations & Medical Disclaimer:</strong> This analysis is generated by artificial intelligence and serves as a
              diagnostic aid. Final diagnosis must be rendered by qualified medical professionals with appropriate clinical correlation. This tool is intended to support, not replace, clinical judgment.
            </p>
          </div>
          <div className="enhanced-signature-line">
            <p>AI Analysis System | Xception Deep Learning Model v2.1</p>
            <p>Generated: {currentDate}</p>
          </div>
        </div>
      </div>
    );
  }
);
EnhancedAnalysisReport.displayName = 'EnhancedAnalysisReport';

// --- Download Button ---
const downloadDivAsPDF = async (divRef: React.RefObject<HTMLDivElement>, filename = 'analysis-report.pdf') => {
  if (!divRef.current) return;
  let html2pdf;
  if ((window as any).html2pdf) {
    html2pdf = (window as any).html2pdf;
  } else {
    html2pdf = (await import('html2pdf.js')).default;
  }
  html2pdf()
    .set({
      margin: [0.5, 0.5, 0.5, 0.5],
      filename: filename,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
    })
    .from(divRef.current)
    .save();
};
const DownloadReportButton = memo(
  ({ onClick }: { onClick: () => void }) => (
    <button className="download-report-btn" onClick={onClick}>
      <DownloadCloud size={18} className="download-report-icon" />
      Download Full Analysis Report (PDF)
    </button>
  )
);
DownloadReportButton.displayName = 'DownloadReportButton';

// --- Server Status Indicator ---
const ServerStatusIndicator = memo(
  ({
    status,
    errorMessage,
  }: {
    status: 'checking' | 'online' | 'offline' | 'error';
    errorMessage: string | null;
  }) => (
    <div className="server-status-container">
      {status === 'checking' && (
        <span className="server-status server-status-checking">
          <AlertTriangle size={16} className="server-status-icon" /> Checking server status...
        </span>
      )}
      {status === 'online' && (
        <span className="server-status server-status-online">
          <CheckCircle size={16} className="server-status-icon" /> Backend connected (Xception model loaded)
        </span>
      )}
      {status === 'offline' && (
        <span className="server-status server-status-offline">
          <AlertCircle size={16} className="server-status-icon" /> Backend not available
        </span>
      )}
      {status === 'error' && (
        <span className="server-status server-status-error">
          <AlertCircle size={16} className="server-status-icon" /> Backend error: {errorMessage}
        </span>
      )}
    </div>
  )
);
ServerStatusIndicator.displayName = 'ServerStatusIndicator';

// --- Loading Indicator ---
const LoadingIndicator = memo(() => (
  <div className="loading-container">
    <div className="loading-spinner"></div>
    <p className="loading-text">Analyzing image with Xception model...</p>
  </div>
));
LoadingIndicator.displayName = 'LoadingIndicator';

// --- Error Display ---
const ErrorDisplay = memo(({ error }: { error: string }) => (
  <div className="error-container">
    <div className="error-content">
      <AlertCircle size={20} className="error-icon" />
      <div>
        <h3 className="error-title">Error processing image</h3>
        <p className="error-message">{error}</p>
      </div>
    </div>
  </div>
));
ErrorDisplay.displayName = 'ErrorDisplay';

// --- Primary Prediction ---
const PrimaryPrediction = memo(({ prediction }: { prediction: PredictionResult }) => {
  const isMalignant = prediction.meta.is_malignant;
  const Icon = isMalignant ? AlertTriangle : CheckCircle;
  const assessmentText = isMalignant ? 'Potentially Malignant' : 'Likely Benign';

  return (
    <div
      className={`primary-prediction ${
        isMalignant
          ? 'primary-prediction-malignant'
          : 'primary-prediction-benign'
      }`}
    >
      <h1 className="primary-prediction-title">
        <Icon size={24} className="primary-prediction-icon" />
        Results: {prediction.prediction.readable_name}
      </h1>
      <p className="primary-prediction-organ">
        <MapPin size={20} className="primary-prediction-icon" />
        Organ/Region: {prediction.prediction.organ}
      </p>
      <p className="primary-prediction-assessment">
        <Activity size={20} className="primary-prediction-icon" />
        Assessment: {assessmentText}
      </p>
      <div className="confidence-container">
        <div className="confidence-header">
          <span>
            <Gauge size={18} className="primary-prediction-icon" />
            Confidence:
          </span>
          <span>{Math.round(prediction.prediction.confidence * 100)}%</span>
        </div>
        <div className="confidence-bar-background">
          <div
            className={`confidence-bar-fill ${
              isMalignant
                ? 'confidence-bar-malignant'
                : 'confidence-bar-benign'
            }`}
            style={{ width: `${prediction.prediction.confidence * 100}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
});
PrimaryPrediction.displayName = 'PrimaryPrediction';

// --- Alternative Predictions ---
const AlternativePredictions = memo(
  ({ alternatives }: { alternatives: AlternativePrediction[] | undefined }) => {
    if (!alternatives || alternatives.length === 0) return null;
    return (
      <div className="alternatives-section">
        <h3 className="alternatives-title">
          <List size={18} style={{ marginRight: '8px' }} />
          Alternative Classifications
        </h3>
        <div className="alternatives-list">
          {alternatives.map((alt, idx) => (
            <div key={idx} className="alternative-item">
              <div className="alternative-details">
                <span className="alternative-name">{alt.readable_name}</span>
                <span className="alternative-organ">({alt.organ})</span>
              </div>
              <span className="alternative-confidence">
                {Math.round(alt.confidence * 100)}%
              </span>
            </div>
          ))}
          {alternatives.length > 0 && (
            <div
              style={{
                marginTop: '12px',
                fontSize: '0.9rem',
                backgroundColor: 'rgba(255, 250, 240, 0.6)',
                padding: '8px',
                borderRadius: '8px',
                borderLeft: '3px solid #f59e0b',
              }}
            >
              <strong>Note:</strong> {alternatives[0].brief_info}
            </div>
          )}
        </div>
      </div>
    );
  }
);
AlternativePredictions.displayName = 'AlternativePredictions';

// --- Main Component ---
function generateRandomId() {
  let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let arr = Array.from({ length: 36 }, () => chars[Math.floor(Math.random() * chars.length)]);
  let str = arr.join('');
  return str.replace(/(.{9})(?=.)/g, '$1-');
}

interface AnalysisResultsProps {
  prediction: PredictionResult | null;
  loading: boolean;
  error: string | null;
  showResults: boolean;
  serverStatus: 'checking' | 'online' | 'offline' | 'error';
  gradCamLoading?: boolean;
  gradCamResult?: GradCamResult | null;
  gradCamError?: string | null;
  onGradCamFetch?: () => void;
}

const AnalysisResults: React.FC<AnalysisResultsProps> = ({
  prediction,
  loading,
  error,
  showResults,
  serverStatus,
  gradCamLoading,
  gradCamResult,
  gradCamError,
  onGradCamFetch,
}) => {

  const defaultTab = useMemo(() => {
    if (prediction?.visualizations?.umap3d_data || prediction?.umap3d_data)
      return 'umap3d';
    if (prediction?.visualizations?.manhattan3d_data || prediction?.manhattan3d_data)
      return 'manhattan3d';
    return 'bar';
  }, [
    prediction?.visualizations?.umap3d_data,
    prediction?.umap3d_data,
    prediction?.visualizations?.manhattan3d_data,
    prediction?.manhattan3d_data
  ]);
  const [activeVisTab, setActiveVisTab] = useState<string>(defaultTab);
  const reportRef = useRef<HTMLDivElement>(null);
  const reportIdRef = useRef<string>(generateRandomId());

  useEffect(() => {
    setActiveVisTab(defaultTab);
    // eslint-disable-next-line
  }, [defaultTab, prediction?.filename]);

  const uploadedImageUrl = useMemo(() => {
    return prediction ? `http://localhost:5000/uploads/${prediction.filename}` : '';
  }, [prediction?.filename]);

  useEffect(() => {

    if (
      activeVisTab === 'umap3d' && prediction && !(prediction.visualizations.umap3d_data || prediction.umap3d_data)
    ) setActiveVisTab('bar');
    if (
      activeVisTab === 'manhattan3d' && prediction && !(prediction.visualizations.manhattan3d_data || prediction.manhattan3d_data)
    ) setActiveVisTab('bar');
    // eslint-disable-next-line
  }, [prediction, activeVisTab]);

  const handleDownloadReport = useCallback(() => {
    downloadDivAsPDF(reportRef, `${reportIdRef.current}.pdf`);
  }, [reportRef]);

  if (!showResults && !loading) return null;

  return (
    <div className="analysis-results-container">
      <ServerStatusIndicator status={serverStatus} errorMessage={error} />

      <div className={`results-section ${showResults ? '' : 'hidden-section'}`}>
        <h2 className="results-title">Analysis Results</h2>
        {loading && <LoadingIndicator />}
        {error && !loading && <ErrorDisplay error={error} />}

        {prediction && !loading && (
          <div className="prediction-results">
            <div className="primary-prediction-outer">
              <PrimaryPrediction prediction={prediction} />
              <div className="uploaded-image-container">
                <div className="uploaded-image-wrapper">
                  <img
                    src={uploadedImageUrl}
                    alt="Uploaded for analysis"
                    className="uploaded-image"
                    loading="lazy"
                  />
                </div>
              </div>
            </div>

            {/* Medical Information Section */}
            {prediction.cancer_info && (
              <CancerInformationSection
                cancerInfo={prediction.cancer_info}
                isMalignant={prediction.meta.is_malignant}
              />
            )}

            {/* Visualizations with new 3D tabs */}
            <div className="visualizations-section">
              <h3 className="visualizations-title">Visualizations</h3>
              <VisualizationTabs
                prediction={prediction}
                activeTab={activeVisTab}
                setActiveTab={setActiveVisTab}
              />
            </div>
            {/* Grad-CAM Section (2D overlays only) */}
            <div className="visualizations-section">
              <GradCamSection
                prediction={prediction}
                gradCamLoading={gradCamLoading}
                gradCamResult={gradCamResult}
                gradCamError={gradCamError}
                onGradCamFetch={onGradCamFetch}
              />
            </div>

            <AlternativePredictions alternatives={prediction.alternatives_info} />

            <div className="details-section">
              <h3 className="details-title">Analysis Details</h3>
              <DownloadReportButton onClick={handleDownloadReport} />
              <EnhancedAnalysisReport
                prediction={prediction}
                downloadableContentRef={reportRef}
                uploadedImageUrl={uploadedImageUrl}
                reportId={reportIdRef.current}
              />
            </div>
          </div>
        )}

        {!prediction && !loading && !error && (
          <div className="empty-results">
            <p>Upload an image to see analysis results</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnalysisResults;