import './App.css';
import ImageUploadArea from './ImageUploadArea';
import { useState, useEffect, useCallback } from 'react';
import LandingPage from './LandingPage';
import AnalysisResults from './AnalysisResults';
import Loader from './Loader';
import { ReactLenis } from 'lenis/react';

// Backend API URL
const API_URL = 'http://localhost:5000/api';

// Interface for Flask backend response aligned with the Python implementation
interface PredictionResult {
  prediction: {
    class: string;
    confidence: number;
    readable_name: string;
    organ: string;
  };
  all_confidences: Record<string, number>;
  filename: string;
  meta: {
    organ: string;
    is_malignant: boolean;
  };
  visualizations: {
    bar_chart: string;
    organ_chart: string;
    pie_chart: string;
    // Added 3D plot keys for new features
    plot3d?: string;
    plot3d_interactive?: string;
    plot3d_data?: any; // JSON for static 3D plot
    plot3d_interactive_data?: any; // JSON for interactive 3D plot
    // New keys for enhanced features
    class_similarity_surface_map?: any; // NEW: 3D Class Similarity Surface Map
    umap3d_data?: any;
    manhattan3d_data?: any;
  };
  cancer_info?: {
    description: string;
    details: string;
    patient_implications: string;
    common_treatments: string;
  };
  alternatives_info?: Array<{
    class: string;
    confidence: number;
    readable_name: string;
    organ: string;
    brief_info: string;
  }>;
  // Optionally, add root-level 3D data if server provides
  plot3d_data?: any;
  plot3d_interactive_data?: any;
  // Optionally, new features at root
  class_similarity_surface_map?: any; // NEW: for root-level fallback
  umap3d_data?: any;
  manhattan3d_data?: any;
}

// For Grad-CAM results
interface GradCamFile {
  layer: string;
  file: string | null;
}
interface GradCamResult {
  status: string;
  gradcam_files: GradCamFile[];
}

function App() {
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [serverStatus, setServerStatus] = useState<'checking' | 'online' | 'offline' | 'error'>('checking');
  const [showResults, setShowResults] = useState<boolean>(false);

  // App loading state (separate from analysis loading)
  const [appLoading, setAppLoading] = useState<boolean>(true);
  const [loadingProgress, setLoadingProgress] = useState<number>(0);

  // Memoize the current image file
  const [currentFile, setCurrentFile] = useState<File | null>(null);

  // Grad-CAM state
  const [gradCamLoading, setGradCamLoading] = useState<boolean>(false);
  const [gradCamError, setGradCamError] = useState<string | null>(null);
  const [gradCamResult, setGradCamResult] = useState<GradCamResult | null>(null);

  // Check if the backend is running on component mount
  useEffect(() => {
    const checkServerStatus = async () => {
      try {
        const response = await fetch(`${API_URL}/health`);
        if (response.ok) {
          const data = await response.json();
          if (data.model_loaded) {
            setServerStatus('online');
          } else {
            setServerStatus('error');
            setError("Backend is online but model is not loaded");
          }
        } else {
          setServerStatus('error');
          setError("Backend returned an error status");
        }
      } catch (err) {
        setServerStatus('offline');
        setError("Cannot connect to backend server");
      }
    };

    if (appLoading) {
      document.body.classList.add('no-scroll');
    } else {
      document.body.classList.remove('no-scroll');
    }

    checkServerStatus();
  }, [appLoading]);

  // This function handles the image selection - memoized to prevent unnecessary re-renders
  const handleImageSelected = useCallback((file: File | null) => {
    setCurrentFile(file);

    if (!file) {
      setPrediction(null);
      setShowResults(false);
      setGradCamResult(null);
      return;
    }

    // Clear previous results when a new image is selected
    setPrediction(null);
    setShowResults(false);
    setError(null);
    setGradCamResult(null);
    setGradCamError(null);
  }, []);

  // Function to handle analysis when button is clicked - memoized
  const handleAnalyzeImage = useCallback(async (file: File) => {
    if (!file) {
      setError("Please select an image first");
      return;
    }

    // Check file type
    const fileExt = file.name.split('.').pop()?.toLowerCase();
    const allowedExtensions = ['png', 'jpg', 'jpeg', 'tiff'];

    if (!fileExt || !allowedExtensions.includes(fileExt)) {
      setError(`File type not allowed. Please upload: ${allowedExtensions.join(', ')}`);
      return;
    }

    // Check file size (10MB limit as per backend)
    if (file.size > 10 * 1024 * 1024) {
      setError("File too large. Maximum size allowed is 10MB");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await fetch(`${API_URL}/predict`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to process image');
      }

      const result: PredictionResult = await response.json();

      // Merge any new root-level 3D/visualization keys from backend to visualizations object for consistency
      const mergedResult: PredictionResult = {
        ...result,
        visualizations: {
          ...result.visualizations,
          // Add new keys if present in result root
          class_similarity_surface_map: result.class_similarity_surface_map || result.visualizations?.class_similarity_surface_map,
          umap3d_data: result.umap3d_data || result.visualizations?.umap3d_data,
          manhattan3d_data: result.manhattan3d_data || result.visualizations?.manhattan3d_data,
        }
      };

      setPrediction(mergedResult);
      setShowResults(true);
      setGradCamResult(null);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message || 'An unexpected error occurred');
      } else {
        setError('An unexpected error occurred');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  // Handler for brain model loading progress updates - memoized
  const handleLoadingProgress = useCallback((progress: number) => {
    setLoadingProgress(progress);

    // Only transition when truly at 100%
    if (progress >= 100) {
      setTimeout(() => {
        setAppLoading(false);
      }, 500);
    }
  }, []);

  // Grad-CAM handler
  const handleGradCamFetch = useCallback(async () => {
    if (!prediction?.filename) {
      setGradCamError('No image available for Grad-CAM visualization.');
      return;
    }
    setGradCamLoading(true);
    setGradCamError(null);
    setGradCamResult(null);

    try {
      const response = await fetch(`${API_URL}/gradcam`, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: prediction.filename })
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate Grad-CAM visualizations');
      }
      const gradcamData: GradCamResult = await response.json();
      setGradCamResult(gradcamData);
    } catch (err: any) {
      setGradCamError(err.message || 'Grad-CAM error');
    } finally {
      setGradCamLoading(false);
    }
  }, [prediction]);

  return (
    <ReactLenis root>
      {/* Main application loader */}
      <Loader
        progress={loadingProgress}
        isComplete={loadingProgress >= 100}
        isVisible={appLoading}
      />

      {/* Main content (visible when loading completes) */}
      <div className={`app-content ${!appLoading ? 'visible' : ''}`}>
        <LandingPage
          onLoadingProgress={handleLoadingProgress}
        />

        {/* Image upload section */}
        <ImageUploadArea
          onImageSelected={handleImageSelected}
          onAnalyzeImage={handleAnalyzeImage}
          loading={loading}
          currentFile={currentFile}
        />

        {/* Simple Analysis Loader */}
        {loading && (
          <div className="analysis-loader-container">
            <div style={{ textAlign: 'center' }}>
              <div className="circular-loader"></div>
              <div className="loader-text">Analyzing Image...</div>
            </div>
          </div>
        )}

        {/* Analysis Results component */}
        <AnalysisResults
          prediction={prediction}
          loading={loading}
          error={error}
          showResults={showResults}
          serverStatus={serverStatus}
          // Grad-CAM props
          gradCamLoading={gradCamLoading}
          gradCamResult={gradCamResult}
          gradCamError={gradCamError}
          onGradCamFetch={handleGradCamFetch}
        />
      </div>
    </ReactLenis>
  );
}

export default App;