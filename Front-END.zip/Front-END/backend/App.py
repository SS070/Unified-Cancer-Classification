import os
import tensorflow as tf
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import uuid
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64
import cv2
import plotly.graph_objects as go

from tensorflow.keras.applications.xception import preprocess_input
from tensorflow.keras.preprocessing import image

# ============= GPU MEMORY MANAGEMENT =============
physical_devices = tf.config.list_physical_devices('GPU')
if physical_devices:
    for device in physical_devices:
        try:
            tf.config.experimental.set_memory_growth(device, True)
            print(f"Memory growth enabled for {device}")
        except Exception as e:
            print(f"Error setting memory growth: {e}")
    try:
        tf.config.set_logical_device_configuration(
            physical_devices[0],
            [tf.config.LogicalDeviceConfiguration(memory_limit=6144)]
        )
        print("GPU memory limited to 6GB")
    except Exception as e:
        print(f"Error limiting GPU memory: {e}")
else:
    print("No GPU found, using CPU")
    os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
VISUALIZATION_FOLDER = 'visualizations'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'tiff'}
MODEL_PATH = 'model/Xception_model.keras'

for folder in [UPLOAD_FOLDER, VISUALIZATION_FOLDER]:
    if not os.path.exists(folder):
        os.makedirs(folder)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['VISUALIZATION_FOLDER'] = VISUALIZATION_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024

# Class labels and category grouping
class_labels = [
    'all_benign', 'all_early', 'all_pre', 'all_pro',
    'brain_glioma', 'brain_menin', 'brain_notumor', 'brain_pitutary',
    'breast_benign', 'breast_malignant',
    'cervix_dyk', 'cervix_koc', 'cervix_mep', 'cervix_pab', 'cervix_sfi',
    'colon_aca', 'colon_bnt',
    'kidney_normal', 'kidney_tumor',
    'lung_aca', 'lung_bnt', 'lung_scc',
    'lymph_cll', 'lymph_fl', 'lymph_mcl',
    'oral_normal', 'oral_scc'
]
organ_categories = {
    'Brain': ['brain_glioma', 'brain_menin', 'brain_notumor', 'brain_pitutary'],
    'Breast': ['breast_benign', 'breast_malignant'],
    'Cervix': ['cervix_dyk', 'cervix_koc', 'cervix_mep', 'cervix_pab', 'cervix_sfi'],
    'Colon': ['colon_aca', 'colon_bnt'],
    'Kidney': ['kidney_normal', 'kidney_tumor'],
    'Lung': ['lung_aca', 'lung_bnt', 'lung_scc'],
    # 'W': ['lymph_cll', 'lymph_fl', 'lymph_mcl'],
    'Oral': ['oral_normal', 'oral_scc'],
    'Blood (Tissue)': ['all_benign', 'all_early', 'all_pre', 'all_pro', 'lymph_cll', 'lymph_fl', 'lymph_mcl']
}
readable_class_names = {
    'all_benign': 'Benign Leukemia',
    'all_early': 'Early Stage Leukemia',
    'all_pre': 'Pre-cancerous leukemia',
    'all_pro': 'Progressive leukemia',
    'brain_glioma': 'Brain Glioma',
    'brain_menin': 'Brain Meningioma',
    'brain_notumor': 'Brain - No Tumor',
    'brain_pitutary': 'Brain Pituitary',
    'breast_benign': 'Breast - Benign',
    'breast_malignant': 'Breast - Malignant',
    'cervix_dyk': 'Cervix Dyskeratosis',
    'cervix_koc': 'Cervix Koilocytosis',
    'cervix_mep': 'Cervix Metaplasia',
    'cervix_pab': 'Cervix Parabasal',
    'cervix_sfi': 'Cervix Superficial',
    'colon_aca': 'Colon Adenocarcinoma',
    'colon_bnt': 'Colon - Benign',
    'kidney_normal': 'Kidney - Normal',
    'kidney_tumor': 'Kidney Tumor',
    'lung_aca': 'Lung Adenocarcinoma',
    'lung_bnt': 'Lung - Benign',
    'lung_scc': 'Lung Squamous Cell Carcinoma',
    'lymph_cll': 'Chronic Lymphomatic Leukemia',
    'lymph_fl': 'Lymphoma Follicular',
    'lymph_mcl': 'Lymphoma Mantle Cell',
    'oral_normal': 'Oral - Normal',
    'oral_scc': 'Oral Squamous Cell Carcinoma'
}

cancer_information = {
    'all_benign': {
    'description': 'Benign hematologic findings with no evidence of leukemia.',
    'details': 'Benign blood and bone marrow profiles typically show normal cell counts and morphology without blast proliferation or genetic abnormalities associated with leukemia.',
    'patient_implications': 'Indicates no presence of leukemia; routine health monitoring is usually sufficient.',
    'common_treatments': 'No treatment required, though regular blood tests may be advised for ongoing health surveillance.'
},
'all_early': {
    'description': 'Early stage Acute Lymphoblastic Leukemia (ALL) with limited leukemic cell proliferation.',
    'details': 'In early ALL, immature lymphoid cells (blasts) begin to accumulate in the bone marrow or blood, but symptoms may be mild and systemic involvement is minimal.',
    'patient_implications': 'Early diagnosis offers a favorable prognosis with effective treatment.',
    'common_treatments': 'Induction chemotherapy, possible targeted therapy, and bone marrow monitoring.'
},
'all_pre': {
    'description': 'Pre-leukemic condition with abnormal hematopoietic cells but not yet full-blown ALL.',
    'details': 'Characterized by clonal hematopoiesis or pre-leukemic mutations; may be classified as a myelodysplastic or pre-ALL state in high-risk individuals.',
    'patient_implications': 'Close surveillance is needed to catch progression to ALL early.',
    'common_treatments': 'Observation, genetic testing, and preventive interventions if high-risk markers are present.'
},
'all_pro': {
    'description': 'Progressive Acute Lymphoblastic Leukemia with extensive blast infiltration.',
    'details': 'Advanced ALL shows high blast count in blood/bone marrow, systemic symptoms (e.g., fatigue, bleeding), and possibly CNS or lymph node involvement.',
    'patient_implications': 'Requires aggressive and immediate treatment to prevent further progression or relapse.',
    'common_treatments': 'Combination chemotherapy, targeted therapies (e.g., tyrosine kinase inhibitors), stem cell transplant, and supportive care.'
},
    'brain_glioma': {
        'description': 'A tumor that originates in the brain\'s glial cells, which support and protect neurons.',
        'details': 'Gliomas account for about 30% of all brain tumors and 80% of malignant brain tumors. They form in the glial cells that surround nerve cells and help them function.',
        'patient_implications': 'Symptoms may include headaches, seizures, personality changes, and neurological deficits depending on tumor location.',
        'common_treatments': 'Surgery (when possible), radiation therapy, chemotherapy, and newer targeted therapies based on molecular profiling.'
    },
    'brain_menin': {
        'description': 'A typically slow-growing tumor that forms in the meninges, the layers of tissue covering the brain and spinal cord.',
        'details': 'Meningiomas make up about 30% of all brain tumors. Most are benign (90-95%), though some can be aggressive.',
        'patient_implications': 'May cause headaches, vision problems, or seizures depending on location. Small, asymptomatic meningiomas often require only monitoring.',
        'common_treatments': 'Observation for small, asymptomatic tumors; surgery for symptomatic or growing tumors; radiation for tumors that can\'t be completely removed.'
    },
    'brain_notumor': {
        'description': 'Normal brain tissue with no detectable neoplastic (tumor) presence.',
        'details': 'Normal brain tissue shows regular cellular architecture with appropriate neural and glial components.',
        'patient_implications': 'No evidence of brain tumor pathology in analyzed tissue.',
        'common_treatments': 'No tumor-directed treatments needed; follow-up may be recommended depending on clinical symptoms.'
    },
    'brain_pitutary': {
        'description': 'An abnormal growth of cells in the pituitary gland, a small hormone-producing gland at the base of the brain.',
        'details': 'Pituitary tumors are typically benign adenomas that can be functioning (hormone-secreting) or non-functioning, and are classified by size as microadenomas (<1cm) or macroadenomas (≥1cm).',
        'patient_implications': 'Symptoms may include hormonal imbalances (excess or deficiency), visual field defects from optic chiasm compression, headaches, and potential pituitary apoplexy in rare cases.',
        'common_treatments': 'Treatment options include observation, medication (dopamine agonists, somatostatin analogs), transsphenoidal surgery, or radiation therapy depending on tumor type, size, and hormone activity.'
    },
    'breast_benign': {
        'description': 'Non-cancerous breast tissue or benign breast conditions.',
        'details': 'Includes conditions like fibrocystic changes, fibroadenomas, intraductal papillomas, and adenosis. These are common and not life-threatening.',
        'patient_implications': 'Benign conditions may cause discomfort or concern but don\'t increase cancer risk significantly.',
        'common_treatments': 'Often no treatment needed beyond monitoring; sometimes surgical removal for symptoms or diagnostic certainty.'
    },
    'breast_malignant': {
        'description': 'Cancerous growth in breast tissue that can invade surrounding tissues and spread to other parts of the body.',
        'details': 'Most commonly originates in the milk ducts (ductal carcinoma) or milk-producing glands (lobular carcinoma). Can be classified by molecular subtypes (hormone receptor status, HER2 status).',
        'patient_implications': 'Treatment success rates are highest with early detection. Regular screening is important.',
        'common_treatments': 'Surgery (lumpectomy or mastectomy), radiation therapy, chemotherapy, hormone therapy, targeted therapy, or immunotherapy depending on cancer type and stage.'
    },
    'cervix_dyk': {
        'description': 'Cervical dyskeratosis showing abnormal keratinization of epithelial cells.',
        'details': 'Dyskeratosis indicates premature or abnormal keratinization of cells and can be associated with HPV infection or other inflammatory conditions.',
        'patient_implications': 'May indicate increased risk for cervical intraepithelial neoplasia or cervical cancer.',
        'common_treatments': 'Monitoring, colposcopy, and possibly biopsy or removal of affected tissue depending on severity.'
    },
    'cervix_koc': {
        'description': 'Cervical koilocytosis showing HPV-related cellular changes.',
        'details': 'Koilocytes are squamous epithelial cells with perinuclear halos and nuclear abnormalities, typically caused by human papillomavirus (HPV) infection.',
        'patient_implications': 'Indicates active HPV infection, which can lead to cervical dysplasia or cancer if persistent.',
        'common_treatments': 'Close monitoring with regular Pap tests, colposcopy, and possible removal of affected tissue.'
    },
    'cervix_mep': {
        'description': 'Cervical metaplasia where one cell type is replaced by another.',
        'details': 'Typically involves replacement of columnar epithelium with squamous epithelium at the transformation zone of the cervix.',
        'patient_implications': 'Usually benign but requires monitoring as it occurs in an area prone to neoplastic changes.',
        'common_treatments': 'Usually observation only; intervention only if abnormal cells are detected.'
    },
    'cervix_pab': {
        'description': 'Parabasal cervical cells, typically found in the deeper layers of cervical epithelium.',
        'details': 'Presence of numerous parabasal cells may indicate atrophy, inflammation, or cellular response to hormonal changes.',
        'patient_implications': 'Often normal finding but may warrant further evaluation in certain contexts.',
        'common_treatments': 'Treatment directed at underlying cause if symptomatic; often no specific treatment needed.'
    },
    'cervix_sfi': {
        'description': 'Cervical superficial cells, normally found on the surface layer of the cervical epithelium.',
        'details': 'Presence of mature squamous epithelial cells is normal in cervical cytology samples.',
        'patient_implications': 'Typically indicates normal cervical cellular maturation pattern.',
        'common_treatments': 'No treatment needed for normal findings; routine screening as recommended.'
    },
    'colon_aca': {
        'description': 'Colorectal adenocarcinoma, a cancer that begins in the cells of the glands lining the colon or rectum.',
        'details': 'Most colorectal cancers begin as polyps, which are abnormal growths inside the colon or rectum that may become cancerous over time.',
        'patient_implications': 'Prognosis depends on stage at diagnosis; early detection through screening significantly improves outcomes.',
        'common_treatments': 'Surgery, chemotherapy, radiation therapy, targeted therapy, or immunotherapy depending on stage and location.'
    },
    'colon_bnt': {
        'description': 'Benign colon tissue without evidence of cancer.',
        'details': 'May include normal tissue or benign conditions like hyperplastic polyps or inflammatory conditions.',
        'patient_implications': 'Regular screening is still important as some benign polyps can become cancerous over time.',
        'common_treatments': 'Often no treatment needed; removal of polyps if present; management of underlying conditions if diagnosed.'
    },
    'kidney_normal': {
        'description': 'Normal kidney tissue showing typical renal architecture.',
        'details': 'Healthy kidney tissue with normal glomeruli, tubules, and supporting structures.',
        'patient_implications': 'No evidence of kidney disease or cancer.',
        'common_treatments': 'No kidney-specific treatment needed; general health maintenance recommended.'
    },
    'kidney_tumor': {
        'description': 'Abnormal growth in kidney tissue that may be benign or malignant.',
        'details': 'The most common type of kidney cancer is renal cell carcinoma (RCC). Other types include transitional cell carcinoma and rare forms such as Wilms tumor.',
        'patient_implications': 'Many kidney tumors are found incidentally during imaging for other conditions. Early-stage tumors have better prognosis.',
        'common_treatments': 'Surgery (partial or complete nephrectomy), ablation therapies, targeted therapy, immunotherapy, or active surveillance for small tumors.'
    },
    'lung_aca': {
        'description': 'Lung adenocarcinoma, a type of non-small cell lung cancer that begins in the cells that line the alveoli.',
        'details': 'Most common type of lung cancer, often developing in the outer regions of the lungs. Can occur in non-smokers more commonly than other types of lung cancer.',
        'patient_implications': 'May be detected earlier than other lung cancers due to peripheral location. Genetic testing may identify targetable mutations.',
        'common_treatments': 'Surgery, radiation therapy, chemotherapy, targeted therapy (for specific mutations), immunotherapy, or combinations based on stage and molecular profile.'
    },
    'lung_bnt': {
        'description': 'Benign lung tissue without evidence of malignancy.',
        'details': 'May include normal lung tissue or benign conditions like hamartoma, inflammatory pseudotumor, or granuloma.',
        'patient_implications': 'Generally good prognosis; follow-up may be recommended to ensure stability.',
        'common_treatments': 'Often observation only; sometimes surgical removal for diagnosis or if causing symptoms.'
    },
    'lung_scc': {
        'description': 'Lung squamous cell carcinoma, a type of non-small cell lung cancer that develops in the flat cells lining the airways.',
        'details': 'Strongly associated with smoking history. Typically develops in the central part of the lungs, near the major bronchi.',
        'patient_implications': 'May cause symptoms earlier than adenocarcinoma due to central location. Tends to grow and spread more slowly than small cell lung cancer.',
        'common_treatments': 'Surgery (if resectable), radiation therapy, chemotherapy, immunotherapy, or combinations depending on stage.'
    },
    'lymph_cll': {
        'description': 'Chronic lymphocytic leukemia/small lymphocytic lymphoma (CLL/SLL), a type of cancer affecting white blood cells.',
        'details': 'Slow-growing cancer of B lymphocytes found in the blood, bone marrow, and lymph nodes. CLL and SLL are essentially the same disease, differing only in where the cancer cells collect.',
        'patient_implications': 'Often asymptomatic and discovered during routine blood tests. Many patients don\'t require immediate treatment ("watch and wait" approach).',
        'common_treatments': 'Observation for asymptomatic patients; chemotherapy, targeted therapy, immunotherapy, or stem cell transplant for progressive disease.'
    },
    'lymph_fl': {
        'description': 'Follicular lymphoma, a type of non-Hodgkin lymphoma that begins in the lymphatic system.',
        'details': 'Slow-growing cancer of B lymphocytes arranged in a circular (follicular) pattern. Second most common type of non-Hodgkin lymphoma.',
        'patient_implications': 'Often responds well to treatment but typically not curable; can transform to more aggressive lymphoma over time.',
        'common_treatments': 'Observation for asymptomatic patients; rituximab-based therapy, radiation, chemotherapy, or stem cell transplant for symptomatic or progressive disease.'
    },
    'lymph_mcl': {
        'description': 'Mantle cell lymphoma, an uncommon type of non-Hodgkin lymphoma.',
        'details': 'Develops from B lymphocytes in the "mantle zone" of lymph nodes. Associated with cyclin D1 protein overexpression due to t(11;14) translocation.',
        'patient_implications': 'Typically diagnosed at advanced stage and can be aggressive, though some cases may progress slowly.',
        'common_treatments': 'Chemotherapy with rituximab, targeted therapies (BTK inhibitors, BCL-2 inhibitors), stem cell transplant for eligible patients.'
    },
    'oral_normal': {
        'description': 'Normal oral tissue showing typical structure without pathological changes.',
        'details': 'Healthy oral mucosa with stratified squamous epithelium and typical underlying supportive tissues.',
        'patient_implications': 'No evidence of oral disease or cancer.',
        'common_treatments': 'No specific treatment needed; routine oral hygiene and dental care recommended.'
    },
    'oral_scc': {
        'description': 'Oral squamous cell carcinoma, a type of cancer that begins in the flat cells lining the oral cavity.',
        'details': 'Most common type of oral cancer. Risk factors include tobacco use, alcohol consumption, and HPV infection.',
        'patient_implications': 'Early detection improves prognosis significantly. Regular oral examinations are important, especially for those with risk factors.',
        'common_treatments': 'Surgery, radiation therapy, chemotherapy, targeted therapy, or combinations depending on stage and location.'
    }
}

# Load the CNN model
print("Loading CNN model...")
try:
    model = tf.keras.models.load_model(MODEL_PATH)
    print("Model loaded successfully with GPU")
except (tf.errors.ResourceExhaustedError, tf.errors.InternalError) as e:
    print(f"Failed to load model with GPU: {e}")
    print("Attempting to load model with CPU only...")
    os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
    model = tf.keras.models.load_model(MODEL_PATH)
    print("Model loaded successfully with CPU")

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def preprocess_image(image_path, target_size=(224, 224)):
    img = Image.open(image_path).convert("RGB")
    img = img.resize(target_size)
    img_array = np.array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = img_array / 255.0
    return img_array

def load_and_preprocess_image(img_path, target_size=(224, 224)):
    high_res_img = cv2.imread(img_path)
    high_res_img = cv2.cvtColor(high_res_img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(high_res_img, target_size, interpolation=cv2.INTER_AREA)
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    return x, img

def make_guided_gradcam_heatmap(img_array, model, last_conv_layer_name, pred_index=None):
    grad_model = tf.keras.models.Model(
        [model.inputs], [model.get_layer(last_conv_layer_name).output, model.output]
    )
    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(img_array)
        if pred_index is None:
            pred_index = tf.argmax(predictions[0])
        class_channel = predictions[:, pred_index]

    grads = tape.gradient(class_channel, conv_outputs)
    grads = tf.maximum(grads, 0)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)
    heatmap = tf.maximum(heatmap, 0)

    if tf.reduce_max(heatmap) != 0:
        heatmap /= tf.reduce_max(heatmap)
    heatmap = tf.where(heatmap < 0.1, 0.0, heatmap)
    return heatmap.numpy()

def superimpose_heatmap(image_arr, heatmap, alpha=0.5):
    if heatmap.shape != image_arr.shape[:2]:
        heatmap = cv2.resize(heatmap, (image_arr.shape[1], image_arr.shape[0]))
    heatmap = cv2.normalize(heatmap, None, 0, 255, cv2.NORM_MINMAX)
    heatmap_color = cv2.applyColorMap(np.uint8(heatmap), cv2.COLORMAP_JET)
    if image_arr.shape[-1] == 3:
        image_arr = cv2.cvtColor(image_arr, cv2.COLOR_RGB2BGR)
    superimposed = cv2.addWeighted(image_arr, 1 - alpha, heatmap_color, alpha, 0)
    return superimposed

last_conv_layer_names = [
    'block14_sepconv2_act',
    'block13_sepconv2_act',
    'block12_sepconv2_act',
    'block11_sepconv2_act',
    'block10_sepconv2_act',
    'block9_sepconv2_act',
    'block8_sepconv2_act',
    'block7_sepconv2_act',
    'block6_sepconv2_act',
    'block5_sepconv2_act'
]

def generate_gradcam_images(img_path, model, layer_names=last_conv_layer_names, visual_subfolder=None):
    x, orig_img = load_and_preprocess_image(img_path)
    gradcam_results = []
    pred = model.predict(x)
    pred_index = np.argmax(pred[0])

    for layer_name in layer_names:
        try:
            heatmap = make_guided_gradcam_heatmap(x, model, layer_name, pred_index=pred_index)
            heatmap = cv2.GaussianBlur(heatmap.astype(np.float32), (5, 5), 1)
            heatmap_uint8 = np.uint8(255 * heatmap)
            overlay_img = superimpose_heatmap(orig_img.copy(), heatmap_uint8)
            gradcam_results.append((layer_name, overlay_img))
        except Exception as e:
            print(f"Could not generate Grad-CAM for layer {layer_name}: {e}")
            gradcam_results.append((layer_name, None))
    return gradcam_results

def get_organ_from_class(class_name):
    for organ, classes in organ_categories.items():
        if class_name in classes:
            return organ
    return "Other"

def create_visualization(prediction_data, filename_base):
    # Make a subfolder for this visualization
    vis_subfolder = os.path.join(app.config['VISUALIZATION_FOLDER'], filename_base)
    if not os.path.exists(vis_subfolder):
        os.makedirs(vis_subfolder)
    visualizations = {}

    # Bar chart (matplotlib)
    plt.figure(figsize=(10, 6))
    top_indices = np.argsort(list(prediction_data['all_confidences'].values()))[-5:]
    top_classes = [class_labels[i] for i in top_indices]
    top_values = [prediction_data['all_confidences'][cls] for cls in top_classes]
    top_readable = [readable_class_names.get(cls, cls) for cls in top_classes]
    plt.barh(top_readable, top_values, color='skyblue')
    plt.xlabel('Confidence')
    plt.title('Top 5 Predictions')
    plt.tight_layout()
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    bar_vis_path = os.path.join(vis_subfolder, f"{filename_base}_bar.png")
    with open(bar_vis_path, 'wb') as f:
        f.write(buf.read())
    plt.close()

    # Interactive bar chart (plotly)
    fig = go.Figure(data=[go.Bar(
        y=top_readable,
        x=top_values,
        orientation='h',
        marker_color='skyblue',
        text=top_values,
        texttemplate='%{text:.2f}',
        textposition='auto'
    )])
    fig.update_layout(
        title='Top 5 Predictions (Interactive)',
        xaxis_title='Confidence',
        yaxis_title='Class',
        hovermode='closest',
        height=600
    )
    bar_vis_html_path = os.path.join(vis_subfolder, f"{filename_base}_bar.html")
    fig.write_html(bar_vis_html_path)

    # Add Plotly JSON for interactive frontend
    bar_plotly_json = fig.to_plotly_json()

    # 3D scatter plot (static & interactive)
    # Static 3D: plotly image (not HTML), Interactive 3D: plotly JSON
    values = [prediction_data['all_confidences'][cls] for cls in class_labels]
    x3d = np.linspace(0, 1, len(class_labels))
    y3d = values
    z3d = np.random.uniform(0.5, 1.5, len(class_labels))
    colors3d = ['crimson' if conf > 0.5 else 'forestgreen' for conf in values]
    labels3d = [readable_class_names.get(cls, cls) for cls in class_labels]

    fig3d = go.Figure(data=[go.Scatter3d(
        x=x3d,
        y=y3d,
        z=z3d,
        mode='markers+text',
        text=labels3d,
        marker=dict(
            size=8,
            color=colors3d,
            opacity=0.8
        )
    )])
    fig3d.update_layout(
        title="3D Confidence Scatter",
        scene=dict(
            xaxis_title='Class Index',
            yaxis_title='Confidence',
            zaxis_title='Randomized Dimension'
        ),
        margin=dict(l=0, r=0, b=0, t=40),
        height=420
    )
    plot3d_json = fig3d.to_plotly_json()
    # Save a PNG snapshot of the 3D plot as well (optional, if kaleido installed)
    try:
        plot3d_png_path = os.path.join(vis_subfolder, f"{filename_base}_3d.png")
        fig3d.write_image(plot3d_png_path, format="png")
    except Exception as e:
        print(f"Could not save PNG 3D plot: {e}")
        #_______________#_________________#

    # Interactive 3D plotly (could be the same as above, or add rotation/animation)
    fig3d_interactive = go.Figure(data=[go.Scatter3d(
        x=x3d,
        y=y3d,
        z=z3d,
        mode='markers+lines+text',
        text=labels3d,
        marker=dict(
            size=8,
            color=colors3d,
            opacity=0.85
        )
    )])
    fig3d_interactive.update_layout(
        title="Interactive 3D Plot (Zoom, Rotate)",
        scene=dict(
            xaxis_title='Class Index',
            yaxis_title='Confidence',
            zaxis_title='Randomized Dimension'
        ),
        margin=dict(l=0, r=0, b=0, t=40),
        height=440
    )
    plot3d_interactive_json = fig3d_interactive.to_plotly_json()
    # _______________#_________________#

    # Organ-wise chart
    plt.figure(figsize=(12, 8))
    organs = {}
    for cls, conf in prediction_data['all_confidences'].items():
        organ = get_organ_from_class(cls)
        if organ not in organs:
            organs[organ] = []
        organs[organ].append((cls, conf))
    organs_list = []
    organ_confs = []
    colors = []
    for organ, class_confs in organs.items():
        max_conf_class, max_conf = max(class_confs, key=lambda x: x[1])
        organs_list.append(organ)
        organ_confs.append(max_conf)
        colors.append('crimson' if max_conf_class in ['all_early', 'all_pre', 'all_pro',
                                                      'brain_glioma', 'brain_menin', 'brain_pitutary',
                                                      'breast_malignant', 'cervix_dyk', 'cervix_koc',
                                                      'colon_aca', 'kidney_tumor', 'lung_aca', 'lung_scc',
                                                      'lymph_cll', 'lymph_fl', 'lymph_mcl',
                                                      'oral_scc'] else 'forestgreen')
    plt.barh(organs_list, organ_confs, color=colors)
    plt.xlabel('Max Confidence')
    plt.title('Organ-wise Highest Confidence')
    plt.tight_layout()
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    organ_vis_path = os.path.join(vis_subfolder, f"{filename_base}_organ.png")
    with open(organ_vis_path, 'wb') as f:
        f.write(buf.read())
    plt.close()

    # Pie chart
    plt.figure(figsize=(8, 8))
    benign_classes = ['all_benign', 'brain_notumor', 'breast_benign', 'colon_bnt',
                      'kidney_normal', 'lung_bnt', 'oral_normal']
    benign_prob = sum(
        prediction_data['all_confidences'][cls] for cls in benign_classes if cls in prediction_data['all_confidences'])
    malignant_prob = sum(prediction_data['all_confidences'][cls] for cls in class_labels
                         if cls not in benign_classes and cls in prediction_data['all_confidences'])
    total = benign_prob + malignant_prob
    if total > 0:
        benign_prob /= total
        malignant_prob /= total
    plt.pie([benign_prob, malignant_prob], labels=['Benign', 'Malignant/Abnormal'],
            colors=['forestgreen', 'crimson'], autopct='%1.1f%%', startangle=90)
    plt.axis('equal')
    plt.title('Benign vs Malignant Assessment')
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    pie_vis_path = os.path.join(vis_subfolder, f"{filename_base}_pie.png")
    with open(pie_vis_path, 'wb') as f:
        f.write(buf.read())
    plt.close()

    visualizations = {
        'bar_chart': f"{filename_base}/{filename_base}_bar.png",
        'organ_chart': f"{filename_base}/{filename_base}_organ.png",
        'pie_chart': f"{filename_base}/{filename_base}_pie.png",
        # new:
        'plot3d_data': plot3d_json,
        'plot3d_interactive_data': plot3d_interactive_json,
    }
    return visualizations

def clear_session_after_predict():
    tf.keras.backend.clear_session()

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({"status": "ok", "model_loaded": model is not None})

@app.route('/api/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({"error": "No image provided"}), 400
    file = request.files['image']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    if file and allowed_file(file.filename):
        filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        filename_base = filename.split('.')[0]

        # Ensure subfolder for this visualization exists
        vis_subfolder = os.path.join(app.config['VISUALIZATION_FOLDER'], filename_base)
        if not os.path.exists(vis_subfolder):
            os.makedirs(vis_subfolder)

        try:
            preprocessed_img = preprocess_image(filepath)
            with tf.device('/CPU:0'):
                prediction = model.predict(preprocessed_img, verbose=0)[0]
            top_index = int(np.argmax(prediction))
            top_class = class_labels[top_index]
            top_confidence = float(prediction[top_index])
            class_confidences = {label: float(pred) for label, pred in zip(class_labels, prediction)}
            result = {
                "prediction": {
                    "class": top_class,
                    "confidence": top_confidence,
                    "readable_name": readable_class_names.get(top_class, top_class),
                    "organ": get_organ_from_class(top_class)
                },
                "all_confidences": class_confidences,
                "filename": filename,
                "meta": {
                    "organ": get_organ_from_class(top_class),
                    "is_malignant": top_class not in ['all_benign', 'brain_notumor', 'breast_benign',
                                                      'colon_bnt', 'kidney_normal', 'lung_bnt', 'oral_normal']
                }
            }
            # Add medical information for the predicted class
            if top_class in cancer_information:
                result["cancer_info"] = cancer_information[top_class]
            else:
                result["cancer_info"] = {
                    "description": "Information not available for this classification.",
                    "details": "Please consult with a healthcare professional for more information.",
                    "patient_implications": "A medical professional should interpret these results.",
                    "common_treatments": "Treatment options should be discussed with your healthcare provider."
                }
            # Add top 3 alternative predictions with their information
            top3_indices = np.argsort(prediction)[-4:-1][::-1]
            top3_classes = [class_labels[i] for i in top3_indices]
            top3_confidences = [float(prediction[i]) for i in top3_indices]
            result["alternatives_info"] = []
            for cls, conf in zip(top3_classes, top3_confidences):
                alt_info = {
                    "class": cls,
                    "confidence": conf,
                    "readable_name": readable_class_names.get(cls, cls),
                    "organ": get_organ_from_class(cls)
                }
                if cls in cancer_information:
                    alt_info["brief_info"] = cancer_information[cls]["description"]
                else:
                    alt_info["brief_info"] = "Information not available for this classification."
                result["alternatives_info"].append(alt_info)
            visualizations = create_visualization(result, filename_base)
            result["visualizations"] = visualizations
            clear_session_after_predict()
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    return jsonify({"error": "File type not allowed"}), 400

@app.route('/api/gradcam', methods=['POST'])
def gradcam():
    data = request.json
    if not data or 'filename' not in data:
        return jsonify({"error": "No filename provided"}), 400
    filename = data['filename']
    img_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.exists(img_path):
        return jsonify({"error": "File not found"}), 404
    filename_base = filename.split('.')[0]
    vis_subfolder = os.path.join(app.config['VISUALIZATION_FOLDER'], filename_base)
    if not os.path.exists(vis_subfolder):
        os.makedirs(vis_subfolder)
    try:
        gradcam_results = generate_gradcam_images(img_path, model, last_conv_layer_names)
        output_files = []
        for layer_name, overlay_img in gradcam_results:
            if overlay_img is not None:
                out_name = f"{filename_base}_gradcam_{layer_name}.png"
                out_path = os.path.join(vis_subfolder, out_name)
                cv2.imwrite(out_path, overlay_img)
                output_files.append({
                    "layer": layer_name,
                    "file": f"{filename_base}/{out_name}"
                })
            else:
                output_files.append({
                    "layer": layer_name,
                    "file": None
                })
        clear_session_after_predict()
        return jsonify({
            "status": "ok",
            "gradcam_files": output_files
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/visualizations/<path:filename>')
def visualization_file(filename):
    return send_from_directory(app.config['VISUALIZATION_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)